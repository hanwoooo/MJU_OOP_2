package course;

public class Major extends Course{
	String major;
	String prerequisite;
	
	Major(String a, String b, String c, String d){
		super(a, b);
		major = c;
		prerequisite = d;
	}
	
	public String get_major() {
		return major;
	}
	
	public String get_prerequisite() {
		return prerequisite;
	}
	
	public String get_all_data() {
		return super.get_all_data()+"\n전공: "+major+"\n선수과목: "+prerequisite;
	}
	
	public void set_major(String a) {
		major = a;
	}
	
	public void set_prerequisite(String a) {
		prerequisite = a;
	}

}
