package course;

public class GenEdu extends Course{
	String class_completion;
	
	GenEdu(String a, String b, String c){
		super(a, b);
		class_completion = c;
	}
	
	public String get_class() {
		return class_completion;
	}
	
	public void set_class(String a) {
		class_completion = a;
	}
	
	public String get_all_data() {
		return super.get_all_data()+"\n이수구분: "+class_completion;
	}
	
}
