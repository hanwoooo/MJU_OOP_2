package course;

public class Elective extends Course{
	Elective(String a, String b){
		super(a, b);
	}
	
	public String get_all_data() {
		return "선택 과목: \n"+super.get_all_data();
	}
}
