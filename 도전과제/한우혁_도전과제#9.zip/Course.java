package course;

public class Course {
	String name;
	String num;
	
	Course(String a, String b){
		name = a;
		num = b;
	}
	
	public String get_name() {
		return name;
	}
	
	public String get_num() {
		return num;
	}
	
	public String get_all_data() {
		return "교과목명: "+name+"\n교과목 번호: "+num;
	}
	
	public void set_name(String a) {
		name = a;
	}
	
	public void set_num(String a) {
		num = a;
	}
}
