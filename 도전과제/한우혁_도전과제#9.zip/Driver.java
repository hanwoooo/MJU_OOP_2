package course;

public class Driver {

	public static void main(String[] args) {
		Course[] course = new Course[5];
		
		course[0] = new Major("자바", "CS101", "컴퓨터공학", "C");
		course[1] = new Major("이산 수학", "CS215", "컴퓨터공학", "없음");
		course[2] = new GenEdu("물리학", "PHS210", "학문기초교양");
		course[3] = new GenEdu("영어 1", "ENG101", "공통교양");
		course[4] = new Elective("테니스", "REC310");
		
		for(int i = 0; i < 5; i++) {
			System.out.println(course[i].get_all_data()+"\n");
		}
	}

}
