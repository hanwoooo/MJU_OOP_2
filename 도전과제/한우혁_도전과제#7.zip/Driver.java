package dice;

public class Driver {

	public static void main(String[] args) {
		Game g = new Game(50);
		g.start();
	}

}
