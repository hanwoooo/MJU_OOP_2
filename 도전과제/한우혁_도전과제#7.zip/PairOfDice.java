package dice;
import java.util.Random;

public class PairOfDice {
	Random rand = new Random();
	int value1;
	int value2;
	
	PairOfDice(){
		value1 = 1;
		value2 = 1;
	}

	public void roll_dice() {
		value1 = rand.nextInt(6)+1;
		value2 = rand.nextInt(6)+1;
	}
	
	 public int get_value1(){
		 return value1;
	 }
	 
	 public int get_value2() {
		 return value2;
	 }
}
