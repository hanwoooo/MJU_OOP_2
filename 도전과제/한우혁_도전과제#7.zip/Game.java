package dice;
import java.util.Scanner;

public class Game {
	PairOfDice dice;
	Player com_player;
	Player user_player;
	Player current_player;
	int target_score;
	
	Game(int a){
		target_score = a;
		com_player = new Player(20);
		user_player = new Player(-1);
		dice = new PairOfDice();
	}
	
	public void start() {
		Scanner sc = new Scanner(System.in);
		current_player = com_player;
		turn_print();
		while (true) {
			if(current_player == com_player) {
				if(!current_player.roll_dice(dice, 20)) {
					if(current_player.get_total_score() >= target_score) {
						victory_print();
						break;
					}
					current_player = user_player;
					turn_print();
				}
			}else {
				if(current_player.roll_dice(dice,-1)) {
					System.out.print("계속 던지시겠습니까? (y/n)");
					String a = sc.next();
					if(a.equals("n")) {
						current_player = com_player;
						turn_print();
					}
				}else {
					if(current_player.get_total_score() >= target_score) {
						victory_print();
						break;
					}
					current_player = com_player;
					turn_print();
				}
			}
		}
		sc.close();
	}
	
	public void turn_print() {
		System.out.println("****************************************");
		if (current_player == com_player) {
			System.out.println("컴퓨터 차례...");
		}else {
			System.out.println("사용자 차례...");
		}
		System.out.println("\n현 점수:");
		System.out.println("  컴퓨터: "+com_player.get_total_score()+"\n  사용자: "+user_player.get_total_score());
	}
	
	public void victory_print() {
		if(current_player == com_player) {
			System.out.println("컴퓨터가 이겼습니다!");
		}else {
			System.out.println("축하합니다. 사용자가 이겼습니다!");
		}
	}

}
