package dice;

public class Player {
	int total_score;
	int current_score;
	int target_score;
	
	Player(int a){
		total_score = 0;
		current_score = 0;
		target_score = a;
	}
	
	public boolean roll_dice(PairOfDice a, int b) {
		a.roll_dice();
		current_score += a.get_value1()+a.get_value2();
		total_score += a.get_value1()+a.get_value2();
		
		System.out.println("DICE: "+a.get_value1()+" + "+a.get_value2()+" = "+(a.get_value1()+a.get_value2()));
		// 모두 1일 때
		if(a.get_value1() == 1 && a.get_value2() == 1) {
			current_score = 0;
			total_score = 0;
			System.out.println("꽝입니다!!!");
			return false;
		}
		// 하나라도 1일 때
		if(a.get_value1() == 1|| a.get_value2() == 1) {
			total_score -=current_score;
			current_score = 0;
			System.out.println("꽝입니다!!!");
			return false;
		}
		
		System.out.println("현 회차 점수: "+current_score);
		System.out.println("총점: "+total_score);
		
		if(total_score >= 50) {
			return false;
		}
		
		if(b == -1) { // 사용자인지
			return true;
		}else {
			if(current_score >=b) { // 한도점수를 넘은 경우
				current_score = 0;
				return false;
			}else {
				return true;
			}
		}
	}
	
	public int get_total_score() {
		return total_score;
	}
	
}
