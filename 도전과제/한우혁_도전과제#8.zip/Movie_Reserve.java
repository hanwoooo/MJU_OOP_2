package movie;
import java.util.Scanner;

public class Movie_Reserve {
	static Scanner sc = new Scanner(System.in);
	static boolean seats[][] = new boolean[5][10];
	
	public static void print_list() {
		System.out.println("=== 영화 목록 ===");
		System.out.println("1. 안중근\n2. 아바타: 물의 길\n3. 명량");
	}
	
	public static int select_movie() {
		while(true) {
			System.out.print("\n보고 싶은 영화를 입력하세요: ");
			int a = sc.nextInt();
			if(a<1 || 3<a) {
				System.out.println("유효하지 않은 영화 번호! 다시 입력하세요.");
			}else {
				return a;
			}
		}	
	}
	
	public static void seat_reset() {
		for(int i = 0; i < 5; i++) {
			if(i == 0) {
				for(int j = 0; j < 10; j++) {
					if(j == 0 || j == 1 || j == 6 || j == 8 || j == 9) {
						seats[i][j] = true;
					}else {
						seats[i][j] = false;
					}
				}
			}else if(i == 1) {
				for(int j = 0; j < 10; j++) {
					if(j == 1 || j == 3 || j == 8 || j == 9) {
						seats[i][j] = true;
					}else {
						seats[i][j] = false;
					}
				}
			}else if(i == 2) {
				for(int j = 0; j < 10; j++) {
					if(j == 0 || j == 1 || j == 3 || j == 6 || j == 8) {
						seats[i][j] = true;
					}else {
						seats[i][j] = false;
					}
				}
			}else if(i == 3) {
				for(int j = 0; j < 10; j++) {
					if(j == 4 || j == 7 || j == 9) {
						seats[i][j] = true;
					}else {
						seats[i][j] = false;
					}
				}
			}else {
				for(int j = 0; j < 10; j++) {
					if(j == 4 || j == 5 || j == 8) {
						seats[i][j] = true;
					}else {
						seats[i][j] = false;
					}
				}
			}
		}
	}
	
	public static void print_seats() {
		System.out.println("\n==== 좌석 배치도 ====");
		System.out.println("  A B C D E F G H I J");
		for(int i = 0; i < 5; i++) {
			System.out.print(i+1+" ");
			for(int j = 0; j < 10; j++) {
				if(seats[i][j]) {
					System.out.print("X ");
				}else {
					System.out.print("O ");
				}
			}
			System.out.println("");
		}
	}
	
	public static void select_seat() {
		int b;
		char c;
		while(true) {
			System.out.print("좌석의 행 번호와 열 문자를 입력하세요(예: 5 B): ");
			b = sc.nextInt();
			c = sc.nextLine().charAt(1); // 한 줄에 b,c를 입력 받기 위함.
			
			if((1<=b && b<=5) && ('A'<=c && c <='J')) {
				// c를 아스키코드로 변환하여 계산
				if(seats[b-1][c-65]) {
					System.out.println("선택한 좌석은 이미 예약도었습니다. 다시 입력하세요.\n");
				}else {
					System.out.println("예약 완료!");
					seats[b-1][c-65] = true;
					break;
				}
			}else {
				System.out.println("유효하지 않은 좌석 선택! 다시 입력하세요.\n");
			}
		}
	}
	public static void main(String[] args) {
		print_list();
		select_movie();
		seat_reset();
		print_seats();
		select_seat();
		sc.close();
	}

}
