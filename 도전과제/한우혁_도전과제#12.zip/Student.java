package student_info;

public class Student {
	String num, name, gender, phone_num, address, major, hobby, intro;
	
	Student(String a, String b, String c, String d, String e, String f, String g, String h){
		num = a;
		name = b;
		gender = c;
		phone_num = d;
		address = e;
		major = f;
		hobby = g;
		intro = h;
	}
	
	public String get_all_data() {
		return num+" "+name+"\t"+gender+"\t"+phone_num+" "+address+" "+major+"\t"+hobby+" "+intro;
	}
}
