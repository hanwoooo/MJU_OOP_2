package student_info;

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

@SuppressWarnings("serial")
public class RegStudent extends JFrame{
	ArrayList<Student> student;
	int stu_num = 0; // 등록된 학생 수

	// 컴포넌트
	ButtonGroup group;
	JLabel nameLabel, genderLabel, numLabel, phone_numLabel, addressLabel, majorLabel, hobbyLabel, introLabel;
	TextField nameField, numField, phone_numField, addressField;
	JRadioButton maleButton, femaleButton;
	JCheckBox exerBox, musicBox, movieBox, tripBox;
	JComboBox<String> majorBox;
	JTextArea introArea;
	JButton saveButton, exitButton;
	RegStudent(){
		Container contPane = getContentPane();
		contPane.setLayout(new BorderLayout());
		setTitle("학생 등록");
		setSize(400, 600);
		setLocation(400, 100);
		
		student = new ArrayList<>();
		
		JPanel basic_infoPanel = new JPanel();
		basic_infoPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		JPanel radioButtonPanel = new JPanel();
		radioButtonPanel.setLayout(new FlowLayout());
		JPanel hobbyPanel = new JPanel();
		hobbyPanel.setLayout(new GridLayout(1,5));
		
		// 레이블 초기화
		nameLabel = new JLabel("성명");
		genderLabel = new JLabel("성별");
		numLabel = new JLabel("학번 ");
		phone_numLabel = new JLabel("전화번호 ");
		addressLabel = new JLabel("주소 ");
		majorLabel = new JLabel("학과명 ");
		hobbyLabel = new JLabel("취미              ");
		introLabel = new JLabel("자기소개");
		
		// 필드 초기화
		nameField = new TextField(20);
		numField = new TextField(8);
		phone_numField = new TextField(13);
		addressField = new TextField(30);
		
		// 체크박스 초기화 -- 성별
		group = new ButtonGroup();
		maleButton = new JRadioButton("남");
		femaleButton = new JRadioButton("여");
		maleButton.setBackground(Color.yellow);
		femaleButton.setBackground(Color.yellow);
		group.add(maleButton);
		group.add(femaleButton);
		radioButtonPanel.add(maleButton);
		radioButtonPanel.add(femaleButton);
		radioButtonPanel.setBackground(Color.yellow);
		
		// 콤보박스 초기화
		majorBox = new JComboBox<String>(new String[]{"학과 선택", "컴퓨터공학과", "전자공학과", "정보통신공학과"});
		
		// 체크박스 초기화 -- 취미
		exerBox = new JCheckBox("운동");
		musicBox = new JCheckBox("음악감상");
		movieBox = new JCheckBox("영화");
		tripBox = new JCheckBox("여행");
		exerBox.setBackground(Color.yellow);
		musicBox.setBackground(Color.yellow);
		movieBox.setBackground(Color.yellow);
		tripBox.setBackground(Color.yellow);

		hobbyPanel.add(hobbyLabel);
		hobbyPanel.add(exerBox);
		hobbyPanel.add(musicBox);
		hobbyPanel.add(movieBox);
		hobbyPanel.add(tripBox);
		hobbyPanel.setBackground(Color.yellow);
		
		// 텍스트 영역 초기화
		introArea = new JTextArea(20, 40); 
        introArea.setLineWrap(true); // 자동 줄바꿈 설정
        introArea.setWrapStyleWord(true); // 단어 단위 줄바꿈 설정
        JScrollPane introScrollPanel = new JScrollPane(introArea);
		
        // 버튼 액션리스너
        ButtonActionListener listener = new ButtonActionListener();
        saveButton = new JButton("저장");
        exitButton = new JButton("종료");
        saveButton.addActionListener(listener);
        exitButton.addActionListener(listener);
        
        // 페널에 추가
		basic_infoPanel.add(nameLabel);
		basic_infoPanel.add(nameField);
		basic_infoPanel.add(genderLabel);
		basic_infoPanel.add(radioButtonPanel);
		basic_infoPanel.add(numLabel);
		basic_infoPanel.add(numField);
		basic_infoPanel.add(phone_numLabel);
		basic_infoPanel.add(phone_numField);
		basic_infoPanel.add(addressLabel);
		basic_infoPanel.add(addressField);
		basic_infoPanel.add(majorLabel);
		basic_infoPanel.add(majorBox);
		basic_infoPanel.add(hobbyPanel);
		basic_infoPanel.add(introLabel);
		basic_infoPanel.add(introScrollPanel);
		
		basic_infoPanel.setBackground(Color.yellow);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		buttonPanel.add(saveButton);
		buttonPanel.add(exitButton);
		buttonPanel.setBackground(Color.yellow);
		
		// 컨테이너에 BorderLayout을 이용하여 각 페널 추가
		contPane.add(basic_infoPanel, BorderLayout.CENTER);
		contPane.add(buttonPanel, BorderLayout.SOUTH);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	// 메인 실행함수
	public static void main(String[] args) {
		RegStudent stu = new RegStudent();
		stu.setVisible(true);
	}
	
	// 학생 정보 저장 함수
	private void save_stu_info() {
		String name = nameField.getText();
		if (name.isEmpty()) {
			JOptionPane.showMessageDialog(RegStudent.this, "이름을 입력하세요.");
			return;
		}
		
		String gender;
		if (maleButton.isSelected()) {
			gender = "남";
		}else if(femaleButton.isSelected()){
			gender = "여";
		}else {
			JOptionPane.showMessageDialog(RegStudent.this, "성별을 선택해 주세요.");
			return;
		}
		
		String num = numField.getText();
		if (num.isEmpty() || num.length() != 8) {
			JOptionPane.showMessageDialog(RegStudent.this, "학번이 틀렸습니다.");
			return;
		}
		
		String phone_num = phone_numField.getText();
		if (phone_num.isEmpty() || phone_num.length() != 13) {
			JOptionPane.showMessageDialog(RegStudent.this, "전화번호가 틀렸습니다.");
			return;
		}
		
		String address = addressField.getText();
		if (address.isEmpty()) {
			JOptionPane.showMessageDialog(RegStudent.this, "주소를 입력하세요.");
			return;
		}
		
		String major = majorBox.getSelectedItem().toString();
		if (major == "학과 선택") {
			JOptionPane.showMessageDialog(RegStudent.this, "학과를 하나 선택하세요.");
			return;
		}
		
		String hobby = "";
		if(exerBox.isSelected()) {
			hobby +="운동 ";
		}
		if(musicBox.isSelected()) {
			hobby += "음악감상 ";
		}
		if(movieBox.isSelected()) {
			hobby += "영화 ";
		}
		if(tripBox.isSelected()){
			hobby += "여행 ";
		}
		
		if(hobby.split(" ").length <2) {
			JOptionPane.showMessageDialog(RegStudent.this, "취미를 두 개 이상 선택하세요.");
			return;
		}
		
		String intro = introArea.getText();
		
		student.add(new Student(num, name, gender, phone_num, address, major, hobby, intro));
		stu_num++;
		
		clear_Form();
	}
	
	// 폼 초기화 함수
	private void clear_Form() {
		nameField.setText("");
        numField.setText("");
        maleButton.setSelected(false);
        femaleButton.setSelected(false);
        phone_numField.setText("");
        addressField.setText("");
        majorBox.setSelectedIndex(0);
        exerBox.setSelected(false);
        musicBox.setSelected(false);
        movieBox.setSelected(false);
        tripBox.setSelected(false);
        introArea.setText("");
	}
	
	private class ButtonActionListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == saveButton) {
				save_stu_info();
			}else {
				System.out.println("학번\t 이름\t성별\t전화번호\t\t주소\t\t학과\t취미\t자기소개");
				 for(Student stu: student) {
					 System.out.println(stu.get_all_data());
				 }
				 System.exit(0);
			}
		}
	}

}
