package first;
import java.util.Scanner;

public class Roma_num {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int year;
		int year_1000, year_100, year_10, year_1; // 순서대로 입력받은 연도의 1000의자리, 100의자리, 10의 자리, 1의 자리
		String year_Roma_num = ""; // 로마숫자로 변환한 연도
		
		while(true) {
			System.out.print("연도를 입력하세요: ");
			year = sc.nextInt();
			
			if (year <1 || year>=5000) {
				System.out.println("잘못 입력된 연도");
			}else {
				year_1000 = year/1000;
				year_100 = (year%1000)/100;
				year_10 = (year%100)/10;
				year_1 = year%10;
				
				// 1000의 자리 변환
				for(int i = 0; i < year_1000; i++) {
					year_Roma_num += "M";
				}
				
				// 100의 자리 변환
				if(year_100 == 9) {
					year_Roma_num += "CM";
				}else if(year_100 == 4){
					year_Roma_num += "CD";
				}else {
					if(year_100 >= 5) {
						year_Roma_num +="D";
						for(int i = 0; i < year_100-5; i++) {
							year_Roma_num += "C";
						}
					}else {
						for(int i = 0; i < year_100; i++) {
							year_Roma_num += "C";
						}
					}
				}
				
				// 10의 자리 변환
				if(year_10 == 9) {
					year_Roma_num += "XC";
				}else if(year_10 == 4){
					year_Roma_num += "XL";
				}else {
					if(year_10 >= 5) {
						year_Roma_num +="L";
						for(int i = 0; i < year_10-5; i++) {
							year_Roma_num += "X";
						}
					}else {
						for(int i = 0; i < year_10; i++) {
							year_Roma_num += "X";
						}
					}
				}
				
				// 1의 자리 변환
				if(year_1 == 9) {
					year_Roma_num += "IX";
				}else if(year_1 == 4){
					year_Roma_num += "IV";
				}else {
					if(year_1 >= 5) {
						year_Roma_num +="V";
						for(int i = 0; i < year_1-5; i++) {
							year_Roma_num += "I";
						}
					}else {
						for(int i = 0; i < year_1; i++) {
							year_Roma_num += "I";
						}
					}
				}
			break;	
			} 
		}
		System.out.println("로마 숫자로 표현한 연도 = "+year_Roma_num);
		sc.close();
	}

}
