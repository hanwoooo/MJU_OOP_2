package first;
import java.util.Scanner;

public class Change_roma {
	
	static int change_num(char num) { // 로마숫자 하나당 정수 반환 메소드
		if(num == 'I') {
			return 1;
		}else if(num == 'V') {
			return 5;
		}else if(num == 'X') {
			return 10;
		}else if(num == 'L') {
			return 50;
		}else if(num == 'C') {
			return 100;
		}else if(num == 'D') {
			return 500;
		}else if(num == 'M') {
			return 1000;
		}else {
			return -1;
		}
	}
	
	static int change_10(String num) { // 10진수 변환 메소드
		int sum = 0;
		int temp;
		for(int i = 0; i < num.length(); i++) {
			temp = change_num(num.charAt(i));
			if(temp == -1) {
				return 0;
			}else if(temp == 1){
				if(i != num.length()-1) {
					if(change_num(num.charAt(i+1)) == 5) {
						sum += 4;
						i++;
					}else if(change_num(num.charAt(i+1)) == 10) {
						sum += 9;
						i++;
					}else {
						sum+=1;
					}
				}else {
					sum+=1;
				}
				
			}else if(temp == 10) {
				if(i !=num.length()-1) {
					if(change_num(num.charAt(i+1)) == 50) {
						sum += 40;
						i++;
					}else if(change_num(num.charAt(i+1)) == 100) {
						sum += 90;
						i++;
					}else {
						sum+=10;
					}
				}else {
					sum+=10;
				}
				
			}
			else if(temp == 100) {
				if(i !=num.length()-1) {
					if(change_num(num.charAt(i+1)) == 500) {
						sum += 400;
						i++;
					}else if(change_num(num.charAt(i+1)) == 1000) {
						sum += 900;
						i++;
					}else {
						sum+=100;
					}
				}else {
					sum+=100;
				}
			}else{
				sum+=temp;
			}
		}
		return sum;
	}

	static int change_8(int num) { // 8진수 변환 메소드
		if(num < 8) {
			return num;
		}else {
			return 10*change_8(num/8)+num%8;
		}
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String roma_num;
		int num_10;
		int num_8;
		System.out.print("로마 숫자를 입력하세요: ");
		roma_num = sc.nextLine();
		num_10 = change_10(roma_num);
		while(num_10>=5000 || num_10<1) {
			System.out.println("잘못 입력된 로마 숫자\n");
			System.out.print("로마 숫자를 입력하세요: ");
			roma_num = sc.nextLine();
			num_10 = change_10(roma_num);
		}
		num_8 = change_8(num_10);
		
		System.out.println("10진수로 변환한 숫자: "+num_10);
		System.out.println("8진수로 변환한 숫자: "+num_8);

		sc.close();
	}

}
