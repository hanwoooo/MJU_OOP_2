package television;
import java.util.Scanner;
public class Television {
	Scanner sc = new Scanner(System.in);
	String name;
	boolean power;
	int channel = 1;
	int volume = 0;
	String all_data;
	
	// 변경자 메소드
	public void set_name(String a) {
		name = a;
	}
	public void set_power(int a) {
		if(a==1) {
			power = true;
		}else {
			power = false;
		}
	}
	public void set_channel(int a) {
		if(channel_check(a)) {
			channel = a;
		}
	}
	public void set_volume(int a) {
		volume = a;
	}
	
	// 접근자 메소드
	public String get_name() {
		return name;
	}
	public boolean get_power() {
		return power;
	}
	public int get_channel() {
		return channel;
	}
	public int get_volume() {
		return volume;
	}
	public String get_all_data() {
		if(power) {
			all_data = "텔레비전 이름: "+name+"\n전원: "+power+"\n현재 채널: "+channel+"\n현재 볼륨: "+volume;
		}
		else {
			all_data = "텔레비전 이름: "+name+"\n전원이 꺼져있습니다.";
		}
		
		return all_data;
	}
	
	// channel 관련 메소드
	public boolean channel_check(int a) {
		if(a<1 || a>99) {
			System.out.println("오류: 새 채널 번호는 유효한 범위 안에 있어야한다.");
			return false;
		}
		else {
			if(power_check()) {
				return true;
			}
			return false;
		}
	}
	public void channel_up() {
		if(channel==99) {
			channel = 1;
		}else {
			if(1<=channel && channel<99) {
				channel++;
			}else {
				System.out.println("오류: 채널 번호는 유효한 범위 안에 있어야 한다.");
			}
		}
	}
	public void channel_down() {
		if(channel == 1) {
			channel = 99;
		}else {
			if(1<channel && channel<=99) {
				channel--;
			}else {
				System.out.println("오류: 채널 번호는 유효한 범위 안에 있어야 한다.");
			}
		}
	}
	
	// power check
	public boolean power_check() {
		return power;
	}
	
	// volume 관련 메소드
	public void volume_up() {
		if(volume!=12) {
			volume++;
		}
	}
	public void volume_down() {
		if(volume!=0) {
			volume--;
		}
	}

}
