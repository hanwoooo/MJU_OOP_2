package television;

public class Driver {

	public static void main(String[] args) {
		Television tv1 = new Television();
		Television tv2 = new Television();
		
		tv1.set_name("삼성");
		tv1.set_power(1);
		tv1.set_channel(1);
		tv1.set_volume(6);
		System.out.println(tv1.get_all_data()+"\n");
		
		tv1.channel_down();
		tv1.volume_up();
		System.out.println(tv1.get_all_data()+"\n");
		
		tv2.set_name("엘지");
		tv2.set_power(1);
		tv2.set_channel(98);
		tv2.set_volume(12);
		System.out.println(tv2.get_all_data()+"\n");
		
		tv2.channel_up();
		tv2.volume_up();
		System.out.println(tv2.get_all_data()+"\n");
	}

}
