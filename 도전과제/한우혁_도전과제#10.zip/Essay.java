package question;

public class Essay extends TestQuestion{
	int line_num;
	
	Essay(int a) {
		line_num = a;
	}
	public void readQuestion(String a) {
		super.question = a;
	}
}
