package question;

public abstract class TestQuestion {
	String question;
	
	public abstract void readQuestion(String a);
	public void printQuestion() {
		System.out.println(question);
	}
}
