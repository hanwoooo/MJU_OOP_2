package question;
import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		TestQuestion[] tq;
		
		tq = new TestQuestion[sc.nextInt()];
		sc.nextLine();
		for(int i = 0; i< tq.length; i++) {
			char a = sc.nextLine().charAt(0);
			if(a == 'e') {
				tq[i] = new Essay(sc.nextInt());
				sc.nextLine();
			}else {
				tq[i] = new MultipleChoice(sc.nextInt());
				sc.nextLine();
			}
			
			tq[i].readQuestion(sc.nextLine());
		}
		
		for(int i = 0; i < tq.length; i++) {
			System.out.print((i+1)+". ");
			tq[i].printQuestion();
		}
		
		sc.close();
	}

}
