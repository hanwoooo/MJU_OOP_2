package question;
import java.util.Scanner;

public class MultipleChoice extends TestQuestion{
	Scanner sc = new Scanner(System.in);
	int ans_num;
	String[] question_multi;
	
	MultipleChoice(int a) {
		ans_num = a;
		question_multi = new String[ans_num];
	}
	public void readQuestion(String a) {
		super.question = a;
		
		for(int i = 0; i < ans_num; i++) {
			question_multi[i] = sc.nextLine();
		}
	}
	public void printQuestion() {
		super.printQuestion();
		for(int i = 0; i < ans_num; i++) {
			System.out.println("   "+(char)(97+i)+". "+ question_multi[i]);
		}
	}
}
