package first;
import java.util.Scanner;

public class Change_12bit {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String input_bit;
		String num_1, num_2, num_3, num_4, num_5, num_6, num_7, num_8, num_9, num_10, num_11, num_12;
		int one, two, three, four;
		String octal = "";
		
		System.out.print("12 비트(bit)의 이진수를 입력하세요: ");
		input_bit = sc.nextLine();
		sc.close();
		
		// 12 비트의 이진수 문자열을 1비트씩 문자열을 쪼개 저장
		num_1 = input_bit.substring(0,1);
		num_2 = input_bit.substring(1,2);
		num_3 = input_bit.substring(2,3);
		num_4 = input_bit.substring(3,4);
		num_5 = input_bit.substring(4,5);
		num_6 = input_bit.substring(5,6);
		num_7 = input_bit.substring(6,7);
		num_8 = input_bit.substring(7,8);
		num_9 = input_bit.substring(8,9);
		num_10 = input_bit.substring(9,10);
		num_11 = input_bit.substring(10,11);
		num_12 = input_bit.substring(11,12);
		
		// 8진수는 3비트로 이루어져있기 때문에 1비트 문자열 3개를 더해 하나로 만들어준다.
		one = Integer.parseInt(num_1+num_2+num_3,2);
		two = Integer.parseInt(num_4+num_5+num_6,2);
		three = Integer.parseInt(num_7+num_8+num_9,2);
		four = Integer.parseInt(num_10+num_11+num_12,2);
		
		// 각 숫자들을 자릿수에 맞춰 하나로 합쳐준다.
		octal += one;
		octal += two;
		octal += three;
		octal += four;
		System.out.println("이진수 "+input_bit+"에 대응하는 8진수는 "+octal+" 이다.");
	}

}
