package first;

import java.util.Scanner;

public class Change_coin {
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		int price; // 가격
		int change; // 거스름돈
		int coin_500;
		int coin_100;
		int coin_50;
		int coin_10;
		int coin_5; 
		int coin_1;
		
		System.out.print("물건의 가격(1000원 이하)을 입력하세요: "); 
		price = sc.nextInt();
		System.out.println(price+"원짜리 물건을 샀고 1,000원을 내셨습니다.");
		change = 1000-price;
		System.out.println("거스름돈은 "+change+"원입니다.");
		System.out.println("거스름돈의 내역은 다음과 같습니다: \n");
		// 500원 개수 계산
		coin_500 = change/500;
		change = change%500;
		// 100원 개수 계산
		coin_100 = change/100;
		change = change%100;
		// 50원 개수 계산
		coin_50 = change/50;
		change = change%50;
		// 10원 개수 계산
		coin_10 = change/10;
		change = change%10;
		// 5원 개수 계산
		coin_5 = change/5;
		change = change%5;
		// 1원 개수 계산
		coin_1 = change;
		
		System.out.println("500원 짜리 동전 개수 = "+coin_500);
		System.out.println("100원 짜리 동전 개수 = "+coin_100);
		System.out.println("50원 짜리 동전 개수 = "+coin_50);
		System.out.println("10원 짜리 동전 개수 = "+coin_10);
		System.out.println("5원 짜리 동전 개수 = "+coin_5);
		System.out.println("1원 짜리 동전 개수 = "+coin_1);
	}
}