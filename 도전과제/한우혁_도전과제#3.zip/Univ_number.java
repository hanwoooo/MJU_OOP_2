package first;
import java.util.Scanner;

public class Univ_number {

	public static void main(String[] args) {		
		Scanner sc = new Scanner(System.in);
		int univ_class_num;
		String class_num; // univ_class_num을 String으로 바꾸어 편하게 나누기 위한 변수
		int year; // 입학년도
		int kind; // 유형
		String univ_in_num; // 입학번호
		int false_count = 0; // 틀린 항목이 몇 개 있는지 세주는 변수
		
		System.out.print("학번은?");
		univ_class_num = sc.nextInt();
		class_num = univ_class_num+"";
		
		sc.close();
		
		year = Integer.parseInt(class_num.substring(2,4));
		kind = Integer.parseInt(class_num.substring(4,5));
		univ_in_num = class_num.substring(5);
		
		System.out.println("입학 연도: "+year);
		System.out.println("입학 유형: "+kind);
		System.out.println("입학 순번: "+univ_in_num);
		
		if (class_num.length() != 8) {
			System.out.println("틀린 이유: 길이가 8이 아니다.");
			false_count++;
		}
		if (Integer.parseInt(class_num.substring(0,2)) != 60) {
			System.out.println("틀린 이유: 60으로 시작하지 않는다.");
			false_count++;
		}
		if (kind != 2 && kind !=5) {
			System.out.println("틀린 이유: 입학 유형");
			false_count++;
		}
		if (univ_in_num.length()!=3 || Integer.parseInt(univ_in_num)==000) {
			System.out.println("틀린 이유: 입학 순번");
			false_count++;
		}
		if (false_count ==0){
			System.out.println("학번이 맞다.");
		}
		
	}

}
