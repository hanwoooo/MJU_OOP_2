package calculator;

@SuppressWarnings("serial")
public class UnknownOpException extends Exception{
	UnknownOpException() {
		super("허용되지 않는 연산자로 인한 예외");
	}
	UnknownOpException(char a){
		super(a+"는 허용되지 않는 연산자이다.");
	}
	UnknownOpException(String a){
		super(a);
	}
}
