package calculator;
import java.util.Scanner;

public class Calculator {
	float result;
	Scanner sc = new Scanner(System.in);
	
	Calculator(){
		result = 0;
	}
	
	public float get_result() {
		return result;
	}
	
	public void set_result(float a) {
		result = a;
	}
	
	public void process() throws DivideByZeroException, UnknownOpException{
		String a;
		System.out.println("result = "+get_result());
		
		while(true) {
			a = sc.nextLine();
			if(a.charAt(0)== 'e' || a.charAt(0) == 'E') {	
				return;
			}
			String[] arr = a.split(" ");
			try {
				result = this.calculate(a.charAt(0), result, Float.parseFloat(arr[1]));	
			}catch (Exception e) {
				throw e;
			}
			System.out.println(Float.parseFloat(arr[1]));
			System.out.println("result "+a+"="+result);
			System.out.println("갱신된 result = "+result+"\n");
		}
	}
	
	public float calculate(char op, float oprd1, float oprd2) throws DivideByZeroException, UnknownOpException{
		if( op != '+' && op !='-' && op !='*' && op !='/') {
			throw new UnknownOpException(op);
		}
		if(op == '/' && (oprd2 == 0 ||(-0.0001<oprd2 && oprd2<0.0001))) {
			throw new DivideByZeroException();
		}
		
		switch (op) {
		case '+':
			return oprd1+oprd2;
		case '-':
			return oprd1-oprd2;
		case '*':
			return oprd1*oprd2;
		case '/':
			return oprd1/oprd2;
		default:
			throw new UnknownOpException(op); // 실행 안됨.
		}
	}
	
	public void handling_divide_exception() {
		System.out.println("0혹은 0에 아주 가까운 값으로 나누려고 시도하여 프로그램이 중단되었습니다.");
	}
	
	public void handling_op_exception() {
		System.out.println("처음부터 다시 시작하세요.");
		System.out.println("연산식을 나타내는 각 라인(line)의 포맷:\n연산자 숫자\n예: + 3\n끝내려면 e(혹은 E)를 입력하세요.");
		result = 0;
		try {
			process();	
		}catch (DivideByZeroException e){
			handling_divide_exception();
		}catch(UnknownOpException e) {
			System.out.println(e.getMessage());
			handling_op_exception();
		}
	}
	
	public static void main(String[] args) {
		Calculator cal = new Calculator();
		System.out.println("계산기를 시작합니다.");
		System.out.println("연산식을 나타내는 각 라인(line)의 포맷:\n연산자 숫자\n예: + 3\n끝내려면 e(혹은 E)를 입력하세요.");
		 
		try {
			cal.process();
		}catch (DivideByZeroException e){
			cal.handling_divide_exception();
			return;
		}catch(UnknownOpException e) {
			System.out.println(e.getMessage());
			cal.handling_op_exception();
		}
		System.out.println("최종 result = "+cal.get_result());
		System.out.println("계산기 프로그램을 종료합니다.");
	}

}
