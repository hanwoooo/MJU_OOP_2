package calculator;

@SuppressWarnings("serial")
public class DivideByZeroException extends Exception{
	DivideByZeroException() {
		super("0으로 나누려고 시도!");
	}
	DivideByZeroException(String a){
		super(a);
	}
}
