package first;
import java.util.Scanner;

public class Can_graduation {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int credit;
		int toeic_grade;
		boolean intern;
		
		System.out.print("총 이수학점을 입력하세요: ");
		credit = sc.nextInt();
		System.out.print("TOEIC 점수를 입력하세요: ");
		toeic_grade = sc.nextInt();
		System.out.print("인턴 여부를 입력하세요(true 혹은 false): ");
		intern = sc.nextBoolean();
		
		sc.close();
		
		if (credit >= 140) {
			if (toeic_grade >= 700 && intern) {
				System.out.println("졸업을 축하합니다");
			}
			else {
				System.out.println("아쉽지만 수료하셨습니다");
			}
		}
		else {
			System.out.println("졸업이 불가합니다");
		}
		
	}

}
