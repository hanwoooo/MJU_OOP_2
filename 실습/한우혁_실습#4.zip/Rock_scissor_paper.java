package first;
import java.util.Scanner;

public class Rock_scissor_paper {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String person_1;
		String person_2;
		
		while(true) {
			System.out.print("선수 1(가위, 바위 혹은 보 중 선택): ");
			person_1 = sc.nextLine();
			System.out.print("선수 2(가위, 바위 혹은 보 중 선택): ");
			person_2 = sc.nextLine();
			
			if (person_1.equals(person_2)) {
				System.out.println("비겼다!");
				continue;
			}else if((person_1.equals("가위") && person_2.equals("보"))||
					(person_1.equals("바위")&&person_2.equals("가위"))||
					(person_1.equals("보")&&person_2.equals("바위"))) 
			{
				System.out.println("선수 1이 이겼다!");
				break;
			}else {
				System.out.println("선수 2가 이겼다!");
				break;
			}
		}
		sc.close();
	}

}
