package student_score;
import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int hw_score;
		int test_score;
		double total_score;
		Student s1 = new Student();
		Student s2 = new Student();
		
		// 학생 두 명 이름 받기
		s1.set_name("선남");
		s2.set_name("선녀");
		
		// 첫 번째 학생 데이터
		System.out.print(s1.get_name()+"의 과제 점수를 입력하라: ");
		hw_score = sc.nextInt();
		while(hw_score<0 || hw_score>100) {
			System.out.println("과제 점수가 0보다 작거나 100보다 크다.");
			System.out.print(s1.get_name()+"의 과제 점수를 다시 입력하라: ");
			hw_score = sc.nextInt();
		}
		s1.set_hw_score(hw_score);
		
		System.out.print(s1.get_name()+"의 시험 점수를 입력하라: ");
		test_score= sc.nextInt();
		while(test_score<0 || test_score>100) {
			System.out.println("시험 점수가 0보다 작거나 100보다 크다.");
			System.out.print(s1.get_name()+"의 시험 점수를 다시 입력하라: ");
			test_score = sc.nextInt();
		}
		// 과제, 시험 점수 받아오기
		s1.set_test_score(test_score);
		hw_score = s1.get_hw_score();
		test_score = s1.get_test_score();
		
		// 총점, 학점 계산
		s1.calculate_score(hw_score, test_score);
		total_score = s1.get_total_score();
		s1.calculate_grade(total_score);
		
		System.out.println(s1.get_name()+"의 총점은 "+total_score+"이고 학점은 "+s1.get_grade()+"이다.");
		
		// 두 번째 학생 데이터
		System.out.print(s2.get_name()+"의 과제 점수를 입력하라: ");
		hw_score = sc.nextInt();
		while(hw_score<0 || hw_score>100) {
			System.out.println("과제 점수가 0보다 작거나 100보다 크다.");
			System.out.print(s2.get_name()+"의 과제 점수를 다시 입력하라: ");
			hw_score = sc.nextInt();
		}
		s2.set_hw_score(hw_score);
		
		System.out.print(s2.get_name()+"의 시험 점수를 입력하라: ");
		test_score= sc.nextInt();
		while(test_score<0 || test_score>100) {
			System.out.println("시험 점수가 0보다 작거나 100보다 크다.");
			System.out.print(s2.get_name()+"의 시험 점수를 다시 입력하라: ");
			test_score = sc.nextInt();
		}
		// 과제, 시험 점수 받아오기
		s2.set_test_score(test_score);
		hw_score = s2.get_hw_score();
		test_score = s2.get_test_score();
		
		// 총점, 학점 계산
		s2.calculate_score(hw_score, test_score);
		total_score = s2.get_total_score();
		s2.calculate_grade(total_score);
		
		System.out.println(s2.get_name()+"의 총점은 "+total_score+"이고 학점은 "+s2.get_grade()+"이다.");
		
		sc.close();
	}

}
