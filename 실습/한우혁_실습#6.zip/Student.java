package student_score;

public class Student {
	String name;
	int homework_score;
	int test_score;
	double total_score;
	char grade;
	
	// 변경자 메소드
	public void set_name(String n) {
		name = n;
	}
	public void set_hw_score(int num) {
		homework_score = num;
	}
	public void set_test_score(int num) {
		test_score = num;
	}
	
	// 계산 메소드
	public void calculate_score(int hw, int test) {
		total_score = 0.4*(double)hw+0.6*(double)test;
	}
	public void calculate_grade(double score) {
		if(score>=90) {
			grade = 'A';
		}else if(80<=score && score<90) {
			grade = 'B';
		}else if(70<=score && score<80) {
			grade = 'C';
		}else if(60<=score && score<70) {
			grade = 'D';
		}else{
			grade = 'F';
		}
	}
	
	// 접근자 메소드
	public String get_name() {
		return name;
	}
	public int get_hw_score() {
		return homework_score;
	}
	public int get_test_score() {
		return test_score;
	}
	public double get_total_score() {
		return total_score;
	}
	public char get_grade() {
		return grade;
	}
	public String[] get_all_data() { // 학생의 모든 데이터를 알려줄 수 있는 메소드
		String arr[] = new String[3];
		arr[0] = name;
		arr[1] = Integer.toString(homework_score);
		arr[2] = Integer.toString(test_score);
		return arr;
	}
}
