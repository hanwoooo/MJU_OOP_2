package interest;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

@SuppressWarnings("serial")
public class Interest_GUI extends JFrame{
	JLabel moneyLabel, inLabel, interestLabel, resultLabel;
	JButton checkButton;
	JTextField moneyField, interestField;

	Interest_GUI(){
		Container contPane = getContentPane();
		setTitle("이자계산기");
		setSize(165, 115);
		JPanel panel = new JPanel();
		panel.setLayout(new FlowLayout());		
		
		moneyLabel = new JLabel("원금");
		moneyField = new JTextField(10);
		inLabel = new JLabel("연이율");
		interestField = new JTextField(10);
		interestLabel = new JLabel("월이자 = ");
		resultLabel = new JLabel("0");
		checkButton = new JButton("확인");
		
		InterestListener listener = new InterestListener();
		checkButton.addActionListener(listener);
		
		panel.add(moneyLabel);
		panel.add(moneyField);
		panel.add(inLabel);
		panel.add(interestField);
		panel.add(interestLabel);
		panel.add(resultLabel, BorderLayout.CENTER);
		panel.add(checkButton, BorderLayout.SOUTH);
		panel.setBackground(Color.green);
		
		contPane.add(panel);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		Interest_GUI gui = new Interest_GUI();
		gui.setVisible(true);
	}

	private class InterestListener implements ActionListener{
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == checkButton) {
				int money;
				double interest;
				money = Integer.parseInt(moneyField.getText());
				interest = Double.parseDouble(interestField.getText());
				resultLabel.setText(Integer.toString((int)(money*interest)/12));		
			}
		}
	}
}
