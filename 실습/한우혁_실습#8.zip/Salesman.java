package sale;

public class Salesman {
	String name;
	int sale;
	Salesman(String s){
		name = s;
		sale = 0;
	}
	
	Salesman(String n, int s){
		name = n;
		sale = s;
	}
	public String get_name() {
		return name;
	}
	
	public int get_sale() {
		return sale;
	}
	
	public String[] get_all_data() {
		String array[] = new String[2];
		array[0] = name;
		array[1] = Integer.toString(sale);
		return array;
	}
	
	public void set_name(String n) {
		name = n;
	}
	public void set_sale(int s) {
		sale = s;
	}
}
