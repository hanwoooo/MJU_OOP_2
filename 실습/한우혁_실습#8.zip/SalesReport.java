package sale;

public class SalesReport {
	int count;
	Salesman man_list[];
	int high;
	int aver;
	static int k = 0;
	
	SalesReport(int a){
		count = a;
		man_list = new Salesman[count];
	}
	public void set_data(String a, int b) {
		man_list[k] = new Salesman(a,b);
		k++;
	}
	public int cal_aver() {
		int temp = 0;
		for(int i = 0; i < count; i++) {
			temp += man_list[i].get_sale();
		}
		temp /=count;
		return temp;
	}
	public String[] find_high() {
		Salesman temp;
		for(int i = 0; i < count-1; i++) {
			for(int j = 0; j<count-1; j++) {
				if (man_list[j].get_sale() < man_list[j+1].get_sale()) {
					temp = man_list[j];
					man_list[j] = man_list[j+1];
					man_list[j+1] = temp;
				}
			}
		}
		return man_list[0].get_all_data();
	}
	
	

}
