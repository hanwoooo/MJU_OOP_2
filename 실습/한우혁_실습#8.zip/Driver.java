package sale;
import java.util.Scanner;
public class Driver {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int count;
		String name;
		int sale;
		String data[];
		System.out.print("판매원들의 수를 입력하세요.: ");
		count = sc.nextInt();
		sc.nextLine();
		SalesReport report = new SalesReport(count);
		
		for(int i = 1; i <= count; i++) {
			System.out.println("판매원"+i+"의 데이터를 입력하세요.");
			System.out.println("판매원의 이름을 입력하세요.");
			name = sc.nextLine();
			System.out.println("판매원의 판매액을 입력하세요.");
			sale = sc.nextInt();
			sc.nextLine();
			report.set_data(name, sale);
		}
		data = report.find_high();
		System.out.println("판매원들의 평균 판매액 = "+ report.cal_aver());
		System.out.println("판매원들의 최대 판매액 = "+ data[1]);
		System.out.println("최대 판매액을 달성한 판매원");
		System.out.println("이름:"+data[0]);
		System.out.println("판매액: "+data[1]);
		
		sc.close();
	}

}
