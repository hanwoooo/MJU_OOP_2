package contest;

import java.util.Scanner;

public class RatingScore {
	Scanner sc = new Scanner(System.in);
	String name;
	int max_grade; // 최대 등급
	int grade; // 받은 등급

	RatingScore(String a, int b) {
		name = a;
		max_grade = b;
		grade = 0;
	}

	public void set_grade() {
		System.out.println(name+"에 대한 당신의 평가 등급은?");
		while (true) {
			System.out.print("1부터 "+max_grade+"까지의 한 정수를 입력하세요: ");
			grade = sc.nextInt();
			if (grade < 1 || grade > max_grade) {
				System.out.println("평가 등급이 범위 밖입니다.");
				grade = 0;
			}else {
				break;
			}
		}
	}
	
	public int get_max_grade() {
		return max_grade;
	}
	
	public int get_grade() {
		return grade;
	}
}
