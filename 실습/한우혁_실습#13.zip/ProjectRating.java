package contest;

public class ProjectRating {
	String pro_name;
	String name;
	RatingScore art_grade;
	RatingScore skill_grade;
	RatingScore commercial_grade;
	
	ProjectRating(String a, String b) {
		pro_name = a;
		name = b;
		art_grade = new RatingScore("예술성", 30);
		skill_grade = new RatingScore("기술성", 40);
		commercial_grade = new RatingScore("상업성", 30);
	}
	
	public void set_grade() {
		System.out.println(pro_name+"에 대한 평가 등급을 입력하세요.");
		art_grade.set_grade();
		skill_grade.set_grade();
		commercial_grade.set_grade();
	}
	
	public int get_total_grade() {
		return art_grade.get_grade()+skill_grade.get_grade()+commercial_grade.get_grade();
	}
	
	public int get_total_max_grade() {
		return art_grade.get_max_grade()+skill_grade.get_max_grade()+commercial_grade.get_max_grade();
	}
	public String get_all_data() {
		return name+"의 "+pro_name+" 평가 점수 = "+ get_total_grade()+"/"+get_total_max_grade();
	}
}
