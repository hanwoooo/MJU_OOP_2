package contest;

public class Driver {

	public static void main(String[] args) {
		ProjectRating pr1 = new ProjectRating("날씨 예측", "선남");
		pr1.set_grade();
		System.out.println();
		
		ProjectRating pr2 = new ProjectRating("미세먼지 개선", "선녀");
		pr2.set_grade();
		System.out.println();
		
		System.out.println("최종 평가 점수:");
		System.out.println(pr1.get_all_data());
		System.out.println(pr2.get_all_data());
	}

}
