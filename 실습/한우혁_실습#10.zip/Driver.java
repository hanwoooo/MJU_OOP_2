package vehicle;

public class Driver {

	public static void main(String[] args) {
		Car car = new Car("제네시스", 40000000, 3500);
		System.out.println(car.get_all_data());
		System.out.println("세금: "+car.cal_tax()+"\n");
		
		Truck truck = new Truck("봉고", 20000000, 2500);
		System.out.println(truck.get_all_data());
		System.out.println("세금: "+truck.cal_tax()+"\n");

		Car car1 = new Car("쏘울", 15000000, 1000);
		System.out.println(car1.get_all_data());
		System.out.println("세금: "+car1.cal_tax());
	}
}
