package vehicle;

public abstract class Vehicle {
	String name;
	int price;
	
	Vehicle(String a, int b){
		name = a;
		price = b;
	}
	
	public String get_name() {
		return name;
	}
	
	public int get_price() {
		return price;
	}
	
	public String get_all_data() {
		return "모델명: "+name+", 가격: "+price;
	}
	
	public abstract double cal_tax();
}
