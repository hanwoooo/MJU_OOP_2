package vehicle;

public class Car extends Vehicle{
	int displacement;
	
	Car(String a, int b, int c){
		super(a, b);
		displacement = c;
	}
	
	public void set_displacement(int a) {
		displacement = a;
	}
	
	public int get_displacement() {
		return displacement;
	}
	
	public double cal_tax() {
		if(displacement >= 3000) {
			return super.get_price()*0.05;
		}else if(1500 <= displacement && displacement < 3000) {
			return super.get_price()*0.03;
		}else {
			return super.get_price()*0.01;
		}
	}
	
	public String get_all_data() {
		return super.get_all_data()+", 배기량: "+displacement;
	}
}
