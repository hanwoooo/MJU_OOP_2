package vehicle;

public class Truck extends Vehicle{
	int weight;
	
	Truck(String a, int b, int c){
		super(a, b);
		weight = c;
	}
	
	public void set_weight(int a) {
		weight = a;
	}
	
	public int get_weight() {
		return weight;
	}
	
	public double cal_tax() {
		if (weight >= 10000) {
			return super.get_price()*0.04;
		}else if(5000 <= weight && weight < 10000) {
			return super.get_price()*0.02;
		}else {
			return super.get_price()*0.01;
		}
	}
	
	public String get_all_data() {
		return super.get_all_data()+", 적재 중량: "+weight;
	}
}
