package first;
import java.util.Scanner;

public class Reverse_string {
	public static void main(String[] arg) {
		Scanner sc = new Scanner(System.in);
		String str;
		String reverse_str;
		String first_string;
		String second_string;
		String last_string;
		
		System.out.print("길이가 3인 문자열을 입력하세요: ");
		str = sc.nextLine();
		System.out.println("입력 문자열: "+str);
		first_string = str.substring(0,1);
		second_string = str.substring(1,2);
		last_string = str.substring(2,3);

		reverse_str = last_string+second_string+first_string;
		System.out.println("출력 문자열: "+reverse_str);
	}
}
