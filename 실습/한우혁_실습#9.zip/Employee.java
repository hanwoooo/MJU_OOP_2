package employee;

public class Employee {
	String name;
	String department;
	Employee(String a, String b){
		name = a;
		department = b;
	}
	
	public String get_name() {
		return name;
	}
	
	public String get_department() {
		return department;
	}
	
	public String get_all_data() {
		return "직원 이름: "+name+", 소속 부서: "+department;
	}
	
	public void set_name(String a) {
		name = a;
	}
	
	public void set_department(String a) {
		department = a;
	}
	
	

}
