package employee;

public class TempEmployee extends Employee {
	int hour_income;
	int time;
	int month_income;
	TempEmployee(String a, String b, int c){
		super(a,b);
		hour_income = c;
		time = 0;
	}
	
	public double cal_month_income() {
		month_income = hour_income*time;
		time = 0;
		return month_income;
	}
	
	public void plus_time(int a) {
		time+=a;
	}
	
	public String get_all_data() {
		return super.get_all_data()+", 시간당 임금: "+hour_income+", 근무시간: "+time;
	}
}
