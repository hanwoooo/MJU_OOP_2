package employee;

public class Driver {

	public static void main(String[] args) {
		RegEmployee reg1 = new RegEmployee("선미", "마케팅", 6000, 0.4);
		System.out.print(reg1.get_all_data());
		System.out.println(", 월급액: "+reg1.cal_month_income());
		TempEmployee temp1 = new TempEmployee("지나", "연구개발", 1);
		temp1.plus_time(300);
		System.out.print(temp1.get_all_data());
		System.out.println(", 월급액: "+temp1.cal_month_income());
	}

}
