package employee;

public class RegEmployee extends Employee {
	int income;
	double bonus;
	RegEmployee(String a, String b, int c, double d){
		super(a,b);
		income = c;
		bonus = d;
	}
	
	public double cal_month_income() {
		return (income/12)*(1+bonus);
	}
	
	public String get_all_data() {
		return super.get_all_data()+", 연봉: "+income+", 보너스 지급률: "+bonus;
	}
}
