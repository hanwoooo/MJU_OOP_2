package first;
import java.util.Scanner;

public class Find_even {
	
	static int findEven(int num) {
		int even = 0;
		while(num >0) {
			if ((num%10)%2 == 0) {
				even++;
			}
			num = num/10;
		}
		return even;
	}
	
	static int recursion(int num) {
		if(num > 10) {
			if(num%2 == 0) {
				return recursion(num/10)+1;
			}else {
				return recursion(num/10);
			}
		}else {
			if(num%2 == 0) {
				return 1;
			}else {
				return 0;
			}
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num;
		int num1;
		int num2;
		
		System.out.print("양의 정수를 입력하세요: ");
		num = sc.nextInt();
		num1 = findEven(num);
		num2 = recursion(num);
		System.out.println("반복 결과: "+num1);
		System.out.println("재귀 결과: "+num2);
		
		sc.close();
	}

}
