package card;
import java.util.Scanner;

public class Driver {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name;
        int num;
        String year;
        int money;
        String tf = "true";
        CardAccount person = new CardAccount("선남", 1001, "0912", 100000);

        while (tf.equals("true")) {
            System.out.println("신용카드를 사용합니다.");
            System.out.print("고객 이름을 입력하세요: ");
            name = sc.nextLine();
            System.out.print("계좌번호를 입력하세요: ");
            num = sc.nextInt();
            sc.nextLine(); // 개행 문자 제거
            System.out.print("카드 만기연월을 입력하세요: ");
            year = sc.nextLine();
            
            if (!person.check(name, num, year)) {
                System.out.println("신원 확인 실패");
            } else {
                System.out.println("신원 확인 성공");
                System.out.print("청구 금액을 입력하세요: ");
                money = sc.nextInt();
                sc.nextLine(); // 버퍼 비우기
                person.update_total(money);
            }
            
            System.out.print("계속하시겠습니까(true 혹은 false): ");
            tf = sc.nextLine(); // tf 입력 받기
        }

        System.out.println("신용카드 결제를 합니다.");
        System.out.print("결제 금액을 입력하세요: ");
        money = sc.nextInt();
        person.cal_total_pay(money);
        person.print();

        sc.close();
    }
}
