package card;

public class CardAccount {
	String name;
	int num;
	String expiration_year;
	int total_money = 0;
	int limit_money;
	public CardAccount(String a, int b, String c, int d) {
		name = a;
		num = b;
		expiration_year = c;
		limit_money = d;
	}
	
	public boolean check(String a, int b, String c) {
		if(name.equals(a) && num == b && expiration_year.equals(c)) {
			return true;
		}else {
			return false;
		}
	}
	
	public void update_total(int a) {
		total_money += a;
		if (total_money>limit_money) {
			System.out.println("신용금액한도초과");
		}
	}
	
	public void cal_total_pay(int a) {
		if(total_money < a) {
			System.out.println("총 결제예정금액만 계산합니다.");
			total_money = 0;
		}else {
			total_money -=a;
		}
	}
	
	public void print() {
		System.out.println("예금주 이름: "+name);
		System.out.println("계좌번호: "+num);
		System.out.println("만기연월: "+expiration_year);
		System.out.println("잔고: "+total_money);
		System.out.println("신용 한도 금액: "+limit_money);
	}

}
