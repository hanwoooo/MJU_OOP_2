package song;

public class Driver {

	public static void main(String[] args) {
		SongCard card = new SongCard(10);
		
		System.out.println(card.get_all_data()+"\n");
		
		System.out.println("노래 하나를 구매하려고 함");
		try {
			card.buy_one_song();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println(card.get_all_data());
		card.active();
		System.out.println(card.get_all_data()+"\n");
		
		System.out.println("노래 20개를 구매하려고 함");

		for(int i = 0; i< 20; i++) {
			try {
				card.buy_one_song();
			}catch(CardNotActivatedException e) {
				System.out.println(e.getMessage());
			}catch(CardEmptyException e) {
				System.out.println(e.getMessage());
				break;
			}
			
		}
		System.out.println(card.get_all_data());
	}

}
