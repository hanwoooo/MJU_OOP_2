package song;

@SuppressWarnings("serial")
public class CardEmptyException extends Exception{
	public CardEmptyException(String a) {
		super(a);
	}
}
