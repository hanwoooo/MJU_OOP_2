package song;

public class SongCard {
	int song_num;
	boolean tf;

	SongCard(int a) {
		song_num = a;
		tf = false;
	}

	public int get_song_num() {
		return song_num;
	}

	public String get_all_data() {
		if (tf) {
			return "남아 있는 노래들의 수: " + song_num + "   활성화되어 있음";
		} else {
			return "남아 있는 노래들의 수: " + song_num + "   활성화되어 있지 않음";
		}

	}

	public void active() {
		tf = true;
		System.out.println("선물카드를 활성화 시킴");
	}

	public void buy_one_song() throws CardNotActivatedException, CardEmptyException{
		if(!tf) {
			throw new CardNotActivatedException("예외 처리함: 카드가 활성화되어 있지 않다.");
		}
		if(song_num == 0){
			throw new CardEmptyException("예외 처리함: 카드에 남아 있는 노래들이 없다.");
		}
		
		song_num--;
		System.out.println("노래 하나 구매함 - "+this.get_all_data());
	}

}
