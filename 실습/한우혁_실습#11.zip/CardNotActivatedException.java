package song;

@SuppressWarnings("serial")
public class CardNotActivatedException extends Exception{
	CardNotActivatedException(String a){
		super(a);
	}
}
