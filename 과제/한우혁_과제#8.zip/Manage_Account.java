package bank;
import java.util.Scanner;

public class Manage_Account {
	Scanner sc = new Scanner(System.in);
	Account[] list = new Account[20];
	static int count;

	Manage_Account() {
		for (int i = 0; i < 20; i++) {
			list[i] = new Account(0, "", 0); // 비어있는 Account객체 생성
		}
		count = 0;
	}

	public void new_account() {
		System.out.println("\n새 고객 계좌 만들기");
		System.out.print("계좌번호를 입력하세요: ");
		int a = sc.nextInt();
		sc.nextLine(); // 남은 버퍼 제거
		if (check_account(a)) {
			System.out.print("새 고객 이름을 입력하세요: ");
			String b = sc.nextLine();
			System.out.print("초기 입금액을 입력하세요: ");
			int c = sc.nextInt();
			sc.nextLine(); // 남은 버퍼 제거
			list[count] = new Account(a, b, c);
			count++;
		} else {
			System.out.println("계좌번호가 이미 사용중입니다.");
		}
	}

	public boolean check_account(int a) {
		if (count == 0) {
			return true;
		} else {
			for (int i = 0; i < count; i++) {
				if (list[i].get_num() == a) {
					return false;
				}
			}
			return true;
		}
	}

	public void deposit() {
		System.out.println("\n입금하기");
		System.out.print("계좌번호를 입력하세요: ");
		int a = sc.nextInt();
		sc.nextLine();
		if (!check_account(a)) {
			System.out.print("입금액을 입력하세요: ");
			int b = sc.nextInt();
			for (int i = 0; i < count; i++) {
				if (list[i].get_num() == a) {
					list[i].deposit(b);
					break;
				}
			}
		} else {
			System.out.println("유효하지 않은 계좌번호입니다.");
		}
	}

	public void withdraw() {
		System.out.println("\n출금하기");
		System.out.print("계좌번호를 입력하세요: ");
		int a = sc.nextInt();
		sc.nextLine();
		if (!check_account(a)) {
			System.out.print("출금액을 입력하세요: ");
			int b = sc.nextInt();
			sc.nextLine();
			for (int i = 0; i < count; i++) {
				if (list[i].get_num() == a) {
					list[i].withdraw(b);
					break;
				}
			}
		} else {
			System.out.println("유효하지 않은 계좌번호입니다.");
		}
	}

	public void account_transfer() { 
		// 출금 계좌: a, 입금계좌: b, 금액: c
		System.out.println("\n계좌이체 하기");
		System.out.print("출금할 계좌번호를 입력하세요: ");
		int a = sc.nextInt();
		sc.nextLine();
		System.out.print("입금할 계좌번호를 입력하세요: ");
		int b = sc.nextInt();
		sc.nextLine();
		if(check_account(a) || check_account(b)) {
			System.out.println("유효하지 않은 계좌번호입니다.");
		}else {
			System.out.print("이체액을 입력하세요: ");
			int c = sc.nextInt();
			sc.nextLine();
			for(int i = 0; i < count; i++) {
				if(list[i].get_num() == a) {
					list[i].withdraw(c);
				}else if(list[i].get_num() == b) {
					list[i].deposit(c);
				}
			}
		}
	}
	public void plus_interest() {
		for(int i = 0; i < count; i++) {
			list[i].plus_interest();
		}
	}
	public String[] get_all_data() {
		String[] str = new String[count];
		for(int i = 0; i < count; i++) {
			str[i] = list[i].get_num()+"\t"+list[i].get_name()+"\t"+list[i].get_balance();
		}
		return str;
	}
}
