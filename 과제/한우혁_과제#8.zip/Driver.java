package bank;

public class Driver {

	public static void main(String[] args) {
		Manage_Account manage = new Manage_Account();
		String[] str = new String[20];
		System.out.println("명지은행에 오신 것을 환영합니다.");
		
		for(int i = 0; i < 3; i++) {
			manage.new_account();
		}

		manage.withdraw();
		manage.account_transfer();
		manage.deposit();
		manage.account_transfer();
		
		for(int i = 0; i < 2; i++) {
			manage.new_account();
		}
		
		manage.withdraw();
		manage.account_transfer();
		manage.deposit();
		
		manage.withdraw();
		manage.deposit();
		
		manage.withdraw();
		
		str = manage.get_all_data();
		System.out.println("\n계좌들의 현 상태:");
		for(int i = 0; i < str.length; i++) {
			System.out.println(str[i]);
		}
		
		manage.plus_interest();
		str = manage.get_all_data();
		
		System.out.println("\n이자 더해주기\n");
		System.out.println("계좌들의 최종 상태:");
		for(int i = 0; i < str.length; i++) {
			System.out.println(str[i]);
		}
	}
}
