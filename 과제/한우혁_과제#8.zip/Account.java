package bank;

public class Account {
	int num;
	String name;
	int balance; // 잔고
	
	Account(int a, String b, int c){
		num = a;
		name = b;
		balance = c;
	}
	public int get_num() {
		return num;
	}
	public int get_balance() {
		return balance;
	}
	public String get_name() {
		return name;
	}
	public void deposit(int a) {
		balance+=a;
	}
	public void withdraw(int a) {
		balance-=a;
	}
	public void plus_interest() {
		balance += balance*0.03;
	}

}
