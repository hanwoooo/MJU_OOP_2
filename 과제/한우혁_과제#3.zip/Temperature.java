package first;
import java.util.Scanner;

public class Temperature {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double temp, change_temp; // 각각 입력받은 온도, 바뀐 온도를 의미함.
		char f_or_c; // 섭씨인지 화씨인지 지정해주는 입력받는 변수
		
		System.out.print("온도를 입력하세요: ");
		temp = sc.nextDouble();
		System.out.println("화씨 온도이면 'F'(혹은 'f')를 입력하고 섭씨 온도이면 'C'(혹은 'c')를 입력하세요: ");
		f_or_c = sc.next().charAt(0);
		
		if(f_or_c == 'F' || f_or_c == 'f') {
			change_temp = (temp-32)/9*5;
			System.out.println("화씨 "+temp+" 도 = 섭씨 "+change_temp+" 도");
			
		}
		else if (f_or_c == 'C' || f_or_c == 'c') {
			change_temp = (temp*9/5)+32;
			System.out.println("섭씨 "+temp+" 도 = 화씨 "+change_temp+" 도");
		}
		else {
			System.out.println("섭씨도 화씨도 아니다 - ");
			System.out.println(" 온도변환을 할 수 없다 - ");
			System.out.println(" 다음 번에는 화씨 온도이면 'F'(혹은 'f')를 입력하고 섭씨 온도이면 'C' (혹은 'c')를 입력하세요: ");
		}
	}

}
