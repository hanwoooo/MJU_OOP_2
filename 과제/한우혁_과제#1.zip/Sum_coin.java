package first;

import java.util.Scanner;

public class Sum_coin {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int coin_500;
		int coin_100;
		int coin_50;
		int coin_10;
		int coin_5;
		int coin_1;
		int sum_of_coins;
		
		System.out.println("돼지 저금통에 각 동전이 몇 개 있나요?");
		System.out.print("500원 : ");
		coin_500 = sc.nextInt();
		System.out.print("100원 : ");
		coin_100 = sc.nextInt();
		System.out.print(" 50원 : ");
		coin_50 = sc.nextInt();
		System.out.print(" 10원 : ");
		coin_10 = sc.nextInt();
		System.out.print("  5원 : ");
		coin_5 = sc.nextInt();
		System.out.print("  1원 : ");
		coin_1 = sc.nextInt();
		
		sum_of_coins = coin_500*500+coin_100*100+ coin_50*50+coin_10*10+ coin_5*5+coin_1;
		System.out.println("저금통의 총액은 "+sum_of_coins+"입니다.");

	}

}
