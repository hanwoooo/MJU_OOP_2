package first;
import java.util.Scanner;

public class Hexadecimal {

	static String recursion_hexa(int num) {
		if (num<16) {
			if (0<=num && num<=9) {
					return Integer.toString(num);
				}else if(num == 10) {
					return "A";
				}else if(num == 11) {
					return "B";
				}else if(num == 12) {
					return "C";
				}else if(num == 13) {
					return "D";
				}else if(num == 14) {
					return "E";
				}else {
					return "F";
				}
		}else {
			if (0<=num%16 && num%16<=9) {
				return recursion_hexa(num/16)+Integer.toString(num%16);
			}else if(num%16 == 10) {
				return recursion_hexa(num/16)+"A";
			}else if(num%16 == 11) {
				return recursion_hexa(num/16)+"B";
			}else if(num%16 == 12) {
				return recursion_hexa(num/16)+"C";
			}else if(num%16 == 13) {
				return recursion_hexa(num/16)+"D";
			}else if(num%16 == 14) {
				return recursion_hexa(num/16)+"E";
			}else {
				return recursion_hexa(num/16)+"F";
			}
		}
	}
		
	static String repeat_hexa(int num) {
		String a = "";
		while(num>0) {
			if (0<=num%16 && num%16 <=9) {
					a+=Integer.toString(num%16);
				}else if(num%16 == 10) {
					a+="A";
				}else if(num%16 == 11) {
					a+="B";
				}else if(num%16 == 12) {
					a+="C";
				}else if(num%16 == 13) {
					a+="D";
				}else if(num%16 == 14) {
					a+="E";
				}else {
					a+="F";
				}
			num = num/16;
		}
		
		String temp = "";
		for (int i = a.length()-1; i>=0; i--) {
			temp+=a.charAt(i);
		}
		
		return temp;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num;
		String num1;
		String num2;
		System.out.print("양의 정수를 입력하세요: ");
		num = sc.nextInt();
		
		num1 = recursion_hexa(num);
		num2 = repeat_hexa(num);
		
		System.out.println("재귀 메소드를 이용하여 구한 16 진수 = "+num1);
		System.out.println("비재귀(반복문 사용) 메소드를 이용하여 구한 16 진수 = "+num2);
		
		sc.close();
	}

}
