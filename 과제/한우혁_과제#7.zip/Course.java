package cosmos;

public class Course {
	static int count = 0;
	String name;
	int max_num;
	int num;
	int score;
	Course(String a, int b, int c){
		name = a;
		max_num = b;
		score = c;
		num = 0;
		count++;
	}
	
	public String get_class_name(){
		return name;
	}
	
	public int get_max_stu() {
		return max_num;
	}
	
	public int get_stu() {
		return num;
	}
	
	public int get_score() {
		return score;
	}
	
	public String get_all_data() {
		return name+"     "+max_num+"         "+num;
	}
	
	public void set_class_name(String a) {
		name = a;
	}
	
	public void set_max_stu(int a) {
		max_num = a;
	}
	
	public void set_score(int a) {
		score = a;
	}
	
	public void increase_max_stu(int a) {
		max_num +=a;
	}
	
	public void increase_stu() {
		num ++;
	}
}
