package cosmos;

public class Student {
	String name;
	int num;
	int score;
	int max_score;
	
	public Student(int a, String b, int c) {
		num = a;
		name = b;
		max_score = c;
		score = 0;
	}
	
	public int get_num() {
		return num;
	}
	
	public String get_name() {
		return name;
	}
	
	public int get_max_score() {
		return max_score;
	}
	
	public int get_score() {
		return score;
	}
	
	public String get_all_data() {
		return num+"   "+name+"    "+score;
	}
	
	public void set_num(int a) {
		num = a;
	}
	
	public void set_score(int a) {
		score =a;
	}
	
	public void set_name(String a) {
		name = a;
	}
	
	public void set_max_score(int a) {
		max_score = a;
	}
}
