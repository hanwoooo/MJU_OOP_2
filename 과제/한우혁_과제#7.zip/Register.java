package cosmos;

public class Register {
	Student stu;
	Course crs;
	Register(Student s, Course c){
		stu = s;
		crs = c;
		if(crs.get_max_stu() > crs.get_stu()) {
			crs.increase_stu();
		}else {
			System.out.println("정원이 차서 수강신청을 할 수 없다.");
		}
		
		if(stu.get_max_score() >= stu.get_score()+crs.get_score()) {
			stu.set_score(stu.get_score()+crs.get_score());
		}else {
			System.out.println("학점 초과로 수강 신청할 수 없다.");
		}
	}
	
	public String get_all_data() {
		return stu.get_name()+": "+crs.get_class_name()+" 수강신청";
	}
}
