package cosmos;

public class Driver {

	public static void main(String[] args) {
		Course crs1 = new Course("알고리즘", 30, 4);
		Course crs2 = new Course("자료구조", 25, 3);

		System.out.println("수강신청 전\n");
		System.out.println("교과목 명    최대 학생수    현재 학생수");
		System.out.println(crs1.get_all_data());
		System.out.println(crs2.get_all_data());
		
		crs1.increase_max_stu(6);
		crs2.increase_max_stu(3);
		System.out.println("\n수강 인원 증원 후\n");
		
		System.out.println("교과목 명    최대 학생수    현재 학생수");
		System.out.println(crs1.get_all_data());
		System.out.println(crs2.get_all_data());
		System.out.println("\n생성된 교과목들의 수: "+Course.count+"\n");
		
		Student stu1 = new Student(2101, "선남", 18);
		Student stu2 = new Student(2102, "선녀", 21);
		Student stu3 = new Student(2103, "길동", 18);
		
		System.out.println("학번    이름    신청 학점수");
		System.out.println(stu1.get_all_data());
		System.out.println(stu2.get_all_data());
		System.out.println(stu3.get_all_data()+"\n");
		
		Register reg1 = new Register(stu1, crs1);
		Register reg2 = new Register(stu2, crs1);
		Register reg3 = new Register(stu2, crs2);
		Register reg4 = new Register(stu3, crs1);
		Register reg5 = new Register(stu3, crs2);
		
		System.out.println(reg1.get_all_data());
		System.out.println(reg2.get_all_data());
		System.out.println(reg3.get_all_data());
		System.out.println(reg4.get_all_data());
		System.out.println(reg5.get_all_data());
		
		System.out.println("\n수강 신청 후\n");
		System.out.println("교과목 명    최대 학생수    현재 학생수");
		System.out.println(crs1.get_all_data());
		System.out.println(crs2.get_all_data());
		
		System.out.println("\n학번    이름    신청 학점수");
		System.out.println(stu1.get_all_data());
		System.out.println(stu2.get_all_data());
		System.out.println(stu3.get_all_data());
	}

}
