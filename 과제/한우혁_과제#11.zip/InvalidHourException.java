package time;

@SuppressWarnings("serial")
public class InvalidHourException extends InvalidTimeFormatException{
	InvalidHourException(String a){
		super(a);
	}
}
