package time;

public class Driver {

	public static void main(String[] args) {
		Time time = new Time();
		
		System.out.println(time.get_all_data());
		try {
			time.change_time("1:11");
		}catch (InvalidTimeFormatException e){
			System.out.println(e.getMessage());
		}
		System.out.println(time.get_all_data());
		
		try {
			time.change_time("24:35");
		}catch (InvalidTimeFormatException e){
			System.out.println(e.getMessage());
		}
		System.out.println(time.get_all_data());
		
		try {
			time.change_time("1:89");
		}catch (InvalidTimeFormatException e){
			System.out.println(e.getMessage());
		}
		System.out.println(time.get_all_data());
		
		try {
			time.change_time("23:58");
		}catch (InvalidTimeFormatException e){
			System.out.println(e.getMessage());
		}
		System.out.println(time.get_all_data());
		
		try {
			time.change_time("1/11");
		}catch (InvalidTimeFormatException e){
			System.out.println(e.getMessage());
		}
		System.out.println(time.get_all_data());
		
		try {
			time.change_time("1:11/");
		}catch (InvalidTimeFormatException e){
			System.out.println(e.getMessage());
		}
		System.out.println(time.get_all_data());
	}

}
