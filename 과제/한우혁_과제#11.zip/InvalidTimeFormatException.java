package time;

@SuppressWarnings("serial")
public class InvalidTimeFormatException extends Exception{
	InvalidTimeFormatException(String a){
		super(a);
	}
}
