package time;

public class Time {
	int hour;
	int minute;

	Time() {
		hour = 0;
		minute = 0;
	}

	public String get_all_data() {
		return "Time: " + String.format("%02d", hour) + ":" + String.format("%02d", minute) + "\n";
	}

	public void change_time(String a) throws InvalidTimeFormatException, InvalidHourException, InvalidMinuteException {
		System.out.println("시간을 " + a + "로 변경한다.");
		String[] arr;

		if (!a.contains(":")) {
			throw new InvalidTimeFormatException("변경시간의 포맷이 유효하지 않다: 시가 정수가 아니다.");
		}
		arr = a.split(":");
		if (!arr[0].matches("[+-]?\\d*(\\.\\d+)?")) {
			throw new InvalidTimeFormatException("변경시간의 포맷이 유효하지 않다: 시가 정수가 아니다.");
		}
		if (!arr[1].matches("[+-]?\\d*(\\.\\d+)?")) {
			throw new InvalidTimeFormatException("변경시간의 포맷이 유효하지 않다: 분이 정수가 아니다.");
		}

		if (0 > Integer.parseInt(arr[0]) || Integer.parseInt(arr[0]) > 23) {
			throw new InvalidHourException("변경 시간의 시가 유효하지 않다: 시가 0부터 23사이의 범위 밖에 있다.");
		}
		if (0 > Integer.parseInt(arr[1]) || Integer.parseInt(arr[1]) > 59) {
			throw new InvalidMinuteException("변경 시간의 분이 유효하지 않다: 분이 0부터 59사이의 범위 밖에 있다.");
		}

		hour = Integer.parseInt(arr[0]);
		minute = Integer.parseInt(arr[1]);

	}
}
