package time;

@SuppressWarnings("serial")
public class InvalidMinuteException extends InvalidTimeFormatException{
	InvalidMinuteException(String a){
		super(a);
	}
}
