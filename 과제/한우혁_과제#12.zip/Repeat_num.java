package repeat_num;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

@SuppressWarnings("serial")
public class Repeat_num extends JFrame {
	JLabel textLabel, outputLabel;
	JTextField numField;
	JButton button;

	Repeat_num() {
		setTitle("중복 번호 제거");
		setSize(500, 100);
		Container contPane = getContentPane();
		JPanel panel = new JPanel();
		panel.setLayout(new FlowLayout());
		textLabel = new JLabel("번호들을 입력하세요 ");
		outputLabel = new JLabel();
		numField = new JTextField(30);
		button = new JButton("중복 번호 제거");

		ButtonListener listener = new ButtonListener();
		button.addActionListener(listener);

		panel.add(textLabel);
		panel.add(numField);
		panel.add(button);
		panel.add(outputLabel);

		contPane.add(panel);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		Repeat_num gui = new Repeat_num();
		gui.setVisible(true);
	}

	private class ButtonListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == button) {
				int temp = 10;
				String[] arr;
				String result = "";
				arr = numField.getText().split(" ");
				for (int i = 0; i < temp; i++) { 
					for (int j = i+1; j < temp; j++) {
						if (Integer.parseInt(arr[i]) == Integer.parseInt(arr[j])) {
							for (int k = j; k < temp-1; k++) {
								arr[k] = arr[k + 1];
							}
							j--;
							temp--;
						}
					}
				}
				
				for(int i = 0; i < temp; i++) {
					result += arr[i]+" ";
				}
				
				outputLabel.setText(result);
			}
		}
	}

}
