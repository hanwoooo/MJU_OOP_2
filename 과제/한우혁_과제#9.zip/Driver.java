package fire;

public class Driver {

	public static void main(String[] args) {
		OverPayCalculator over = new OverPayCalculator(8000);
		over.plus_time(50);
		over.set_st_time(6);
		over.set_sn_time(2);
		System.out.println("주말 근무 직원의 주급: "+over.cal_week_income());
		
		DangerPayCalculator danger = new DangerPayCalculator(10000);
		danger.plus_time(36);
		danger.set_dg_time(6);
		System.out.println("위험 근무 직원의 주급: "+danger.cal_week_income());
	}

}
