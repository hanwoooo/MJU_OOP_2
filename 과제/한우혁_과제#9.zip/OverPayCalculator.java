package fire;

public class OverPayCalculator extends BasicPayCalculator{
	int st_time;
	int sn_time;
	OverPayCalculator(int a){
		super(a);
		st_time = 0;
		sn_time = 0;
	}
	
	public void set_st_time(int a) {
		st_time = a;
	}
	
	public void set_sn_time(int a) {
		sn_time = a;
	}
	
	public int cal_week_income() {
		return st_time*super.hour_income*2+sn_time*super.hour_income*3+super.cal_week_income();
	}
	
}
