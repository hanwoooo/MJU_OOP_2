package fire;

public class BasicPayCalculator {
	int week_income = 0;
	int hour_income;
	int time;
	BasicPayCalculator(int a){
		hour_income = a;
		time = 0;
	}
	
	public void plus_time(int a) {
		time+=a;
	}
	
	public void set_time(int a) {
		time = a;
	}
	
	public void set_income(int a) {
		hour_income = a;
	}
	
	public int cal_week_income() {
		if(time > 40) {
			week_income += 40*hour_income+(time-40)*hour_income*1.5;
		}else {
			week_income += hour_income*time;
		}
		
		return week_income;
	}

}
