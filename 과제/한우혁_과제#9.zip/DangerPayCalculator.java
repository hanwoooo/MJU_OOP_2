package fire;

public class DangerPayCalculator extends BasicPayCalculator{
	int dg_time;
	DangerPayCalculator(int a){
		super(a);
		dg_time = 0;
	}
	
	public void set_dg_time(int a) {
		dg_time = a;
	}
	
	public int cal_week_income() {
		return dg_time*super.hour_income*5+super.cal_week_income();
	}
}
