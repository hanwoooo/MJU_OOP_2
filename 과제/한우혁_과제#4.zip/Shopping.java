package first;
import java.util.Scanner;

public class Shopping {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int price; // 금액 입력 받는 변수
		int sum_price = 0; // 지출 금액의 총합
		int max_item_count = 3; // 최대로 살 수 있는 물건의 개수
		int item_count = 1; // 현재 고르고 있는 물건의 번호
		int max_money = 100000; // 최대로 사용할 수 있는 액수
		
		while(max_item_count != 0) {
			System.out.println("상품 가격이 "+max_money+"를 넘지 않은 최대 "+max_item_count+"개의 상품을 살 수 있다");
			System.out.print("상품 "+item_count+"의 가격을 입력하세요: ");
			price = sc.nextInt();
			if (price <max_money) {
				sum_price+=price;
				System.out.println("상품 "+item_count+"구매 가능");
				System.out.println("지출 금액: "+sum_price);
				max_money -=price;
				max_item_count--;
				item_count++;
			}else if(price == max_money){ // 문제에는 안 나와 있지만 혹시 몰라 구현해놨습니다.
				sum_price+=price;
				max_money -=price;
				max_item_count--;
				System.out.println("상품 "+item_count+"구매 가능");
				System.out.println("지출 금액: "+sum_price);
				if (max_item_count != 0) {
					System.out.println("상품 3개를 다 사기전에 금액을 모두 소진하였습니다.");
				}
				break;
			}else {
				System.out.println("상품 "+item_count+" 구매 불가");
			}
			System.out.println(""); // 구분을 위한 줄바꿈
		}
		System.out.println("잔액: "+max_money);
		sc.close();
		
	}

}
