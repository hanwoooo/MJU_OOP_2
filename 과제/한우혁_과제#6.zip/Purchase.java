package purchase_item;
import java.util.Scanner;

public class Purchase {
	Scanner sc = new Scanner(System.in);
	String item;
	int group_unit; // 묶음단위
	int group_price, one_price; // 묶음 가격, 단일 가격
	int item_num;
	int total_price;
	
	// 접근자 메소드
	public String get_item() {
		return item;
	}
	public int get_group_unit() {
		return group_unit;
	}
	public int get_group_price() {
		return group_price;
	}
	public int get_one_price() {
		return one_price;
	}
	public int get_item_num() {
		return item_num;
	}
	public int get_total_price() {
		return total_price;
	}

	// 변경자 메소드
	public void set_item(String a) {
		item = a;
	}
	public void set_group_unit(int a) {
		group_unit = a;
	}
	public void set_group_price(int a) {
		group_price = a;
	}
	public void set_one_price(int a) {
		one_price = a;
	}
	public void set_item_num(int a) {
		item_num = a;
	}
	
	// 입력 메소드
	public void input() {
		System.out.print("구매하는 물품의 이름을 입력하세요: ");
		item = sc.nextLine();
		System.out.print("물품의 묶음 단위를 입력하세요: ");
		group_unit = sc.nextInt();
		while (group_unit <= 0) {
			System.out.println("묶음 단위가 0이하일 수 없습니다. 다시 입력하세요.");
			group_unit = sc.nextInt();
		}
		
		System.out.print("물품의 묶음 가격을 입력하세요: ");
		group_price = sc.nextInt();
		while (group_price <= 0) {
			System.out.println("묶음 가격이 0원 이하일 수 없습니다. 다시 입력하세요.");
			group_price = sc.nextInt();
		}
		
		System.out.print("\n물품의 단위(개당)가격을 입력하세요: ");
		one_price = sc.nextInt();
		while (one_price <= 0) {
			System.out.println("개당 가격이 0원 이하일 수 없습니다. 다시 입력하세요.");
			one_price = sc.nextInt();
		}
		
		System.out.print("\n구매한 물품들의 갯수를 입력하세요: ");
		item_num = sc.nextInt();
		while (item_num <= 0) {
			System.out.println("물품들의 갯수가 0개 이하일 수 없습니다. 다시 입력하세요.");
			one_price = sc.nextInt();
		}
	}
	
	// 출력 메소드
	public void print() {
		System.out.println("구매 내역");
		System.out.println("  물품명: "+item);
		System.out.println("  물품들의 갯수: "+item_num);
		System.out.println("  단위(개당)가격: "+one_price);
		System.out.println("  묶음 가격: "+group_price);
		System.out.println("  묶음 단위: "+group_unit+"\n");
	}
	
	// 계산 메소드
	public void calculate_total_price() {
		total_price = (item_num/group_unit)*group_price+(item_num%group_unit)*one_price;
	}
}
