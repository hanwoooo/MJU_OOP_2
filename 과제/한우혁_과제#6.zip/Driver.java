package purchase_item;

public class Driver {

	public static void main(String[] args) {
		Purchase p1 = new Purchase();
		int total_price;
		int one_price;
		
		p1.input();
		p1.print();
		
		p1.calculate_total_price();
		total_price = p1.get_total_price();
		one_price = total_price/p1.get_item_num();
		
		System.out.println("총 구매 가격: "+total_price);
		System.out.println("개당 구매 가격: "+one_price);
	}

}
 