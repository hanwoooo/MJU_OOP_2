package first;
import java.util.Scanner;

public class Student_info {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String all_info;
		String name;
		String stu_num;
		String major;
		int index;
		String rest_info;
		
		System.out.print("이름, 학번과 학과를 입력하세요: ");
		all_info = sc.nextLine();
		index = all_info.indexOf("/");
		name = all_info.substring(0,index);
		rest_info = all_info.substring(index+1);
		
		index = rest_info.indexOf("/");
		stu_num = rest_info.substring(0,index);
		rest_info = rest_info.substring(index+1);
		
		major = rest_info;
		
		System.out.println("이름: "+name);
		System.out.println("학번: "+stu_num);
		System.out.println("학과: "+major);
		
		sc.close();
	}

}
