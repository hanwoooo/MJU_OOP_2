package bank;

public abstract class Fixed_deposit extends Deposit{
	int money; // 원금
	Fixed_deposit(String a, int b, int c, double d, int e){
		super(a, b, c, d);
		money = e;
	}
	
	public int get_money() {
		return money;
	}
	
	public String get_all_data() {
		return super.get_all_data()+"\n원금: "+money;
	}
}
