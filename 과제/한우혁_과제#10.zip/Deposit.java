package bank;

public abstract class Deposit {
	String name;
	int num;
	int period;
	double interest_rate;
	
	Deposit(String a, int b, int c, double d){
		name = a;
		num = b;
		period = c;
		interest_rate = d;
	}
	
	public int get_period() {
		return period;
	}
	
	public double get_interest_rate() {
		return interest_rate;
	}
	
	public String get_all_data() {
		return "예금주 이름: "+name+"\n계좌번호: "+num+"\n계약기간: "+period+"\n연이율: "+interest_rate;
	}
	public abstract int cal_interest();
}
