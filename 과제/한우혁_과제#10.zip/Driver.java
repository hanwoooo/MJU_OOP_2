package bank;

public class Driver {

	public static void main(String[] args) {
		Simple_fixed_deposit deposit = new Simple_fixed_deposit("선남", 100, 12, 0.05, 10000000);
		System.out.println(deposit.get_all_data());
		System.out.println("원리금: "+deposit.cal_interest()+"\n");
		
		Compound_fixed_deposit deposit1 = new Compound_fixed_deposit("선녀", 200, 12, 0.05, 10000000);
		System.out.println(deposit1.get_all_data());
		System.out.println("원리금: "+deposit1.cal_interest()+"\n");
		
		Installment_saving deposit2 = new Installment_saving("길동", 300, 12, 0.05, 100000);
		System.out.println(deposit2.get_all_data());
		System.out.println("원리금: "+deposit2.cal_interest()+"\n");
	}

}
