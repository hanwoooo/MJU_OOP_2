package bank;

public class Compound_fixed_deposit extends Fixed_deposit{
	Compound_fixed_deposit(String a, int b, int c, double d, int e){
		super(a,b,c,d,e);
	}
	
	public int cal_interest() {
		return (int)(super.get_money()*Math.pow((1+super.get_interest_rate()/12),super.get_period()));
	}
	
	public String get_all_data() {
		return "정기예금(복리)\n"+super.get_all_data();
	}
}
