package bank;

public class Installment_saving extends Deposit{
	int money; // 월불입액
	
	Installment_saving(String a, int b, int c, double d, int e){
		super(a,b,c,d);
		money = e;
	}
	
	public int cal_interest() {
		return (int)(money*super.get_period()*(1+super.get_interest_rate()*(super.get_period()+1)/24));
	}
	
	public String get_all_data() {
		return "정기적금\n"+super.get_all_data()+"\n월불입액: "+money;
	}

}
